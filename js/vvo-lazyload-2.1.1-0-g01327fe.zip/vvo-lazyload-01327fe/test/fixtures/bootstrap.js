var merge = require('merge');
require('../../node_modules/in-viewport/test/fixtures/bootstrap.js');
h = merge(h, require('./helper.js'));
